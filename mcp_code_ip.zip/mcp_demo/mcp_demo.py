# src/mcp_llm_bridge/main.py
import os
import asyncio
from dotenv import load_dotenv
from mcp import StdioServerParameters
from mcp_llm_bridge.config import BridgeConfig, LLMConfig
from mcp_llm_bridge.bridge import BridgeManager
import colorlog
import logging
import re
import json
from datetime import datetime
from fpdf import FPDF
import textwrap
import sys

def create_geolocation_pdf(response_text: str, ip_address: str, output_dir: str = "reports") -> str:
    """
    将 IP 地理位置信息文本转换为 PDF 文件。
    
    Args:
        response_text: LLM 返回的文本响应
        ip_address: 查询的 IP 地址
        output_dir: PDF 文件保存的目录

    Returns:
        str: 生成的 PDF 文件的路径
    """
    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)

    # 创建 PDF 对象
    pdf = FPDF()
    pdf.add_page()
    
    # 添加中文支持（如果需要）
    try:
        pdf.add_font('SimSun', '', os.path.join(os.path.dirname(__file__), 'simsun.ttf'), uni=True)
    except:
        print("Warning: Chinese font not found, using default font")
    
    # 设置标题
    pdf.set_font('Helvetica', 'B', 16)
    pdf.cell(0, 10, 'IP Geolocation Report', 0, 1, 'C')
    pdf.ln(10)

    # 添加时间戳
    pdf.set_font('Helvetica', 'I', 10)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    pdf.cell(0, 10, f'Generated at: {timestamp}', 0, 1, 'R')
    pdf.ln(5)

    # 添加查询的 IP 地址
    pdf.set_font('Helvetica', 'B', 12)
    pdf.cell(0, 10, f'Query IP: {ip_address}', 0, 1)
    pdf.ln(5)

    # 添加响应内容
    pdf.set_font('Helvetica', '', 12)
    
    # 将响应文本按行分割
    lines = response_text.split('\n')
    for line in lines:
        # 跳过空行
        if not line.strip():
            pdf.ln(5)
            continue
            
        # 处理长行，确保不会超出页面宽度
        wrapped_lines = textwrap.wrap(line.strip(), width=80)
        for wrapped_line in wrapped_lines:
            pdf.cell(0, 10, wrapped_line, 0, 1)

    # 提取位置信息用于文件名（从响应文本中查找城市或地区信息）
    location = "unknown"
    location_patterns = [
        r"城市[：:]\s*([^\n,，]*)",
        r"地区[：:]\s*([^\n,，]*)",
        r"省/州[：:]\s*([^\n,，]*)",
        r"国家/地区[：:]\s*([^\n,，]*)"
    ]
    
    for pattern in location_patterns:
        match = re.search(pattern, response_text)
        if match:
            location = match.group(1).strip()
            break

    # 生成文件名：IP_地区.pdf
    ip_part = ip_address.replace(".", "_")
    # 移除任何不适合作为文件名的字符
    location = re.sub(r'[<>:"/\\|?*]', '_', location)
    
    filename = f"{ip_part}_{location}.pdf"
    filepath = os.path.join(output_dir, filename)
    
    # 如果文件已存在，添加时间戳以避免覆盖
    if os.path.exists(filepath):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{ip_part}_{location}_{timestamp}.pdf"
        filepath = os.path.join(output_dir, filename)
    
    pdf.output(filepath)
    return filepath

async def main():
    # Load environment variables
    load_dotenv()
    
    print("\nWelcome to the AI Assistant!")
    print("I can help you with:")
    print("1. Web searches (e.g., 'search for latest AI developments')")
    print("2. IP geolocation (e.g., 'what is the location of IP 8.8.8.8')")
    print("\nJust type your question naturally, and I'll figure out what you need!")
    
    user_input = input("\nEnter your question (or 'quit' to exit): ")
    
    if user_input.lower() == 'quit':
        return

    # 获取当前脚本的绝对路径
    current_file = os.path.abspath(__file__)
    script_dir = os.path.dirname(current_file)
    
    # 构建服务脚本的路径
    web_search_path = os.path.join(script_dir, "web_search.py")
    local_ip_path = os.path.join(script_dir, "local_ip.py")

    # 检查文件是否存在，如果不存在则尝试在父目录中查找
    if not os.path.exists(web_search_path) or not os.path.exists(local_ip_path):
        parent_dir = os.path.dirname(script_dir)
        web_search_path = os.path.join(parent_dir, "web_search.py")
        local_ip_path = os.path.join(parent_dir, "local_ip.py")
        
        if not os.path.exists(web_search_path) or not os.path.exists(local_ip_path):
            print(f"Error: Required service files not found.")
            print(f"Looked in:")
            print(f"  - {script_dir}")
            print(f"  - {parent_dir}")
            print("Please ensure web_search.py and local_ip.py are in the correct location.")
            return

    # 打印找到的文件路径（调试用）
    print(f"\nUsing service files:")
    print(f"Web Search: {web_search_path}")
    print(f"IP Geolocation: {local_ip_path}")

    # 确保 Python 解释器路径正确
    python_executable = sys.executable
    print(f"Using Python: {python_executable}")

    # 配置通用的 LLM 设置
    llm_config = LLMConfig(
        api_key=os.getenv("NVIDIA_API_KEY", "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"),
        model=os.getenv("NVIDIA_MODEL", "nvidia/llama-3.1-nemotron-ultra-253b-v1"),
        base_url=os.getenv("NVIDIA_BASE_URL", "https://integrate.api.nvidia.com/v1")
    )

    # 创建两个服务的配置
    web_search_config = BridgeConfig(
        mcp_server_params=StdioServerParameters(
            command=python_executable,  # 使用完整的 Python 解释器路径
            args=[web_search_path],
            env=os.environ.copy()
        ),
        llm_config=llm_config,
        system_prompt=(
            "You are a helpful assistant with access to two tools:\n"
            "1. 'web_search': For searching the internet and finding information\n"
            "2. 'get_ip_geolocation': For finding the geographical location of IP addresses\n"
            "\nWhen a user asks a question:\n"
            "- If they want to know about an IP address location, use 'get_ip_geolocation'\n"
            "- For all other information queries, use 'web_search'\n"
            "\nIf you see an IP address pattern (like '8.8.8.8') in the query, prefer using get_ip_geolocation."
        )
    )

    ip_geo_config = BridgeConfig(
        mcp_server_params=StdioServerParameters(
            command=python_executable,  # 使用完整的 Python 解释器路径
            args=[local_ip_path],
            env=os.environ.copy()
        ),
        llm_config=llm_config,
        system_prompt=(
            "You are a helpful assistant with access to two tools:\n"
            "1. 'web_search': For searching the internet and finding information\n"
            "2. 'get_ip_geolocation': For finding the geographical location of IP addresses\n"
            "\nWhen a user asks a question:\n"
            "- If they want to know about an IP address location, use 'get_ip_geolocation'\n"
            "- For all other information queries, use 'web_search'\n"
            "\nIf you see an IP address pattern (like '8.8.8.8') in the query, prefer using get_ip_geolocation."
        )
    )

    # 检测是否包含 IP 地址模式
    ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
    contains_ip = bool(re.search(ip_pattern, user_input))
    
    # 选择配置
    config = ip_geo_config if contains_ip else web_search_config
    
    # 使用选定的配置处理请求
    async with BridgeManager(config) as bridge:
        try:
            print(f"\nProcessing your request...")
            response = await bridge.process_message(user_input)
            print(f"\nResponse:\n{response}")

            # 如果是 IP 地理位置查询，将结果保存为 PDF
            if contains_ip:
                try:
                    # 从用户输入中提取 IP 地址
                    ip_match = re.search(ip_pattern, user_input)
                    if ip_match:
                        ip_address = ip_match.group(0)
                        
                        # 获取响应文本
                        response_text = ""
                        if isinstance(response, str):
                            response_text = response
                        elif isinstance(response, dict) and "content" in response:
                            # 如果响应是字典格式，提取文本内容
                            for item in response["content"]:
                                if item.get("type") == "text":
                                    response_text += item["text"] + "\n"
                        
                        if response_text:
                            # 生成 PDF 报告
                            pdf_path = create_geolocation_pdf(response_text, ip_address)
                            print(f"\nGeolocation report saved as: {pdf_path}")
                        else:
                            print("\nError: No response text available for PDF generation")
                    else:
                        print("\nError: Could not extract IP address from input")

                except Exception as e:
                    print(f"\nError generating PDF report: {str(e)}")
                    import traceback
                    traceback.print_exc()

        except Exception as e:
            print(f"\nError occurred: {e}")
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    # Optional: Configure logging
    # logging.basicConfig(level=logging.INFO)
    # logging.getLogger("mcp_llm_bridge").setLevel(logging.DEBUG)
    # logging.getLogger("mcp").setLevel(logging.DEBUG)
    # logging.getLogger("httpx").setLevel(logging.WARNING)
    asyncio.run(main())