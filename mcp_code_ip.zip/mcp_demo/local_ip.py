import httpx
import json
from mcp.server.fastmcp import FastMCP
from dotenv import load_dotenv

# Load environment variables if you have any specific configurations
load_dotenv()

# Initialize FastMCP server
mcp = FastMCP("ip_geolocator")

@mcp.tool()
async def get_ip_geolocation(ip_address: str) -> str:
    """
    Retrieves geographical location information for a given IP address.
    Uses the api.iplocation.net service.

    Args:
        ip_address: The IP address (e.g., "111.199.191.234") to get geolocation for.

    Returns:
        A JSON string containing the geolocation information or an error message.
    """
    if not ip_address:
        return json.dumps({"error": "IP address cannot be empty."}, ensure_ascii=False, indent=4)

    # 使用 api.iplocation.net
    url = f"https://api.iplocation.net/?ip={ip_address}"

    try:
        async with httpx.AsyncClient() as client:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
            }
            response = await client.get(url, timeout=10.0, headers=headers)
            response.raise_for_status()
            
            data = response.json()
            
            # 格式化返回数据
            location_info = {
                "query": ip_address,
                "status": "success",
                "country": data.get("country_name"),
                "country_code": data.get("country_code2"),
                "region": data.get("region_name"),
                "city": data.get("city"),
                "latitude": data.get("latitude"),
                "longitude": data.get("longitude"),
                "isp": data.get("isp"),
                "organization": data.get("organization"),
                "timezone": data.get("time_zone"),
                "source": "api.iplocation.net"
            }
            
            return json.dumps(location_info, indent=4, ensure_ascii=False)

    except httpx.HTTPStatusError as e:
        return json.dumps({
            "error": f"HTTP error occurred: {e.response.status_code}",
            "details": e.response.text,
            "query": ip_address
        }, indent=4, ensure_ascii=False)
    except httpx.RequestError as e:
        return json.dumps({
            "error": f"Request failed: {str(e)}",
            "query": ip_address
        }, indent=4, ensure_ascii=False)
    except json.JSONDecodeError as e:
        return json.dumps({
            "error": "Failed to parse API response",
            "details": str(e),
            "query": ip_address
        }, indent=4, ensure_ascii=False)
    except Exception as e:
        return json.dumps({
            "error": f"An unexpected error occurred: {str(e)}",
            "query": ip_address
        }, indent=4, ensure_ascii=False)

if __name__ == "__main__":
    print("IP Geolocation MCP Service starting...")
    mcp.run(transport='stdio')
